# UTPod
Program for EE312 Lab 5 - UTPod

INSTRUCTIONS FOR RUNNING THIS PROGRAM
1. After unzipping, place the program files in a directory in a Linux environment
2. Execute the "make" command without the quotes
3. Run executable "Ut_Pod" (Remember to precede with "./")
4. Status of the Ut_Pod based off the tests performed in UtPodDriver.cpp are printed to the screen 
